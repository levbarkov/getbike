<?php
/**
 * Created by PhpStorm.
 * User: schr1ger
 * Date: 013 13.11.18
 * Time: 11:46
 */

return [
    //'Rental ID' => 'Город'
];